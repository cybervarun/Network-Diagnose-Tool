# Enterprise Windows Endpoint Diagnostic Platform

## Phase 3 Additions

- Searchable offline troubleshooting knowledge base for DNS, gateway, DHCP/APIPA, firewall, proxy/VPN, and adapter issues
- Article detail views with symptoms, checks, fixes, escalation criteria, and related diagnostic rules
- Release-readiness CLI summary for Windows packaging validation
- Build script checks for package metadata and distributable artifacts
- Generated Windows install bundle with PowerShell install and uninstall helpers

A production-ready, offline-first diagnostic platform for enterprise Windows endpoint troubleshooting. Diagnoses network issues, explains root causes, provides evidence-based recommendations, and generates professional reports.

**Status:** Phase 2 Complete ✅ | Production Ready | 42/42 Tests Passing

---

## Overview

This platform automates the diagnosis of enterprise Windows endpoint networking issues using deterministic rules and collected evidence. Unlike traditional command-runners, it:

- **Explains WHY** issues occur, not just that they exist
- **Shows evidence** supporting each diagnosis
- **Recommends actions** with step-by-step remediation
- **Teaches engineers** with learning articles
- **Works offline** as a portable executable
- **Generates reports** in multiple formats (Text, HTML, JSON)

### Key Features

✅ **13 Enterprise Diagnostic Rules**
- DNS resolution failures
- Gateway configuration issues  
- Internet connectivity problems
- Firewall and security status
- Network adapter problems
- And 8 more...

✅ **Multi-Format Reporting**
- Professional text reports with Unicode formatting
- Beautiful HTML reports with styled output
- Machine-readable JSON for automation
- All formats include evidence and recommendations

✅ **Configuration Management**
- Enable/disable rules dynamically
- Set rule priorities
- Plugin-ready architecture with real module discovery
- JSON-based persistence

✅ **Production-Grade Code**
- 100% test passing rate (42/42 tests)
- 62% code coverage
- Type hints throughout
- Comprehensive error handling
- Professional logging

---

## Quick Start

### Installation

```bash
# Install in development mode
pip install -e ".[dev]"

# Verify installation
python -m NetworkDiagnosticPlatform.cli --help
```

### First Diagnostic

```bash
# Offline mode (testing, no system changes)
python -m NetworkDiagnosticPlatform.cli --offline

# Real system diagnostic (requires admin rights)
python -m NetworkDiagnosticPlatform.cli -o "./reports"

# List available rules
python -m NetworkDiagnosticPlatform.cli --list-rules
```

### Output

Reports are generated in `./reports/` directory:
- `diagnostic_report_[hostname]_[timestamp].txt` - Text report
- `diagnostic_report_[hostname]_[timestamp].html` - HTML report
- `diagnostic_report_[hostname]_[timestamp].json` - JSON report

---

## Command Line Usage

### Basic Commands

```bash
# Run full diagnostic with all report formats
python -m NetworkDiagnosticPlatform.cli

# Run in testing mode (uses mock data)
python -m NetworkDiagnosticPlatform.cli --offline

# Custom output directory
python -m NetworkDiagnosticPlatform.cli -o "C:\Diagnostic Reports"

# Specific report formats only
python -m NetworkDiagnosticPlatform.cli -f "html,json"

# Custom hostname
python -m NetworkDiagnosticPlatform.cli -H "workstation-01"

# Verbose logging for debugging
python -m NetworkDiagnosticPlatform.cli -v
```

### Rule Management

```bash
# List all available rules
python -m NetworkDiagnosticPlatform.cli --list-rules

# Show details for DNS rules
python -m NetworkDiagnosticPlatform.cli --rule-details dns

# Show details for gateway rules
python -m NetworkDiagnosticPlatform.cli --rule-details gateway

# Load custom plugin rules from a directory
python -m NetworkDiagnosticPlatform.cli --offline --plugin-path ./plugins
```

### Knowledge Base and Release Workflow

```bash
# List all bundled troubleshooting articles
python -m NetworkDiagnosticPlatform.cli --knowledge-list

# Search offline guidance
python -m NetworkDiagnosticPlatform.cli --knowledge-search dns

# Show article details
python -m NetworkDiagnosticPlatform.cli --knowledge-detail dhcp_apipa

# Check release readiness from the CLI
python -m NetworkDiagnosticPlatform.cli --release-check

# Build and validate distributable artifacts
python scripts/build_package.py --check --windows-bundle

# Install from the generated Windows bundle
powershell -ExecutionPolicy Bypass -File .\dist\windows\install.ps1 -OfflineSmokeTest
```

### Help

```bash
python -m NetworkDiagnosticPlatform.cli --help
```

---

## Diagnostic Rules

### Critical Connectivity

1. **DNS Resolution Failure** - Cannot resolve hostnames
2. **Missing Default Gateway** - No gateway configured
3. **No Internet Connectivity** - Cannot reach external services
4. **Default Gateway Unreachable** - Gateway not responding

### Network Configuration

5. **No IP Address Assigned** - Adapter has no IP
6. **IPv4-Only Configuration** - No IPv6 detected
7. **Multiple Adapters Disconnected** - Multiple adapters failing
8. **Unusual DNS Servers** - Misconfigured DNS

### Firewall & Security

9. **Windows Firewall Active** - Firewall enabled (informational)

### DNS & Resolution

10. **No DNS Servers Configured** - No DNS servers
11. **DNS Cache May Be Stale** - Resolver cache issues

### Adapter Issues

12. **Network Adapter Disabled** - Adapter is disabled
13. **Limited Network Connectivity** - No outbound access

---

## Report Examples

### Text Report Output

```
╔════════════════════════════════════════════════════════════════╗
║        ENTERPRISE ENDPOINT DIAGNOSTIC REPORT                    ║
╚════════════════════════════════════════════════════════════════╝

Hostname: workstation-01
Generated: 2026-07-05 15:30:00
Total Findings: 3

─── HIGH SEVERITY ───

▶ DNS Resolution Failure
  Severity: [HIGH]
  
  Explanation: The endpoint cannot resolve domain names to IP 
  addresses. This prevents connecting to services by hostname.
  
  Root Cause: DNS servers are unreachable, misconfigured, or 
  not responding. The resolver cache may also be corrupted.
  
  Supporting Evidence:
  • DNS resolution test returned false
  • Configured DNS servers: 8.8.8.8, 8.8.4.4
  
  Recommended Actions:
  1. Verify DNS server settings: Settings > Network > DNS
  2. Test DNS: nslookup microsoft.com
  3. Flush DNS cache: ipconfig /flushdns
```

### HTML Report

- Professional styling with gradient background
- Color-coded severity badges
- Responsive grid layout
- Summary dashboard with statistics
- Print-friendly CSS

### JSON Report

```json
{
  "metadata": {
    "hostname": "workstation-01",
    "generated": "2026-07-05T15:30:00",
    "total_findings": 3,
    "findings_by_severity": {
      "high": 2,
      "medium": 1,
      "info": 0
    }
  },
  "findings": [
    {
      "title": "DNS Resolution Failure",
      "severity": "high",
      "explanation": "...",
      "root_cause": "...",
      "evidence": ["..."],
      "recommended_actions": ["..."],
      "learning_articles": ["..."],
      "escalation_criteria": ["..."]
    }
  ]
}
```

---

## Architecture

```
┌─────────────────────────────────────────────┐
│       CLI Entry Point                       │
│  (Command line interface & user interaction)│
└──────────────────┬──────────────────────────┘
                   │
    ┌──────────────┴──────────────┐
    │                             │
    ▼                             ▼
┌────────────┐          ┌──────────────┐
│ Evidence   │          │ Configuration│
│ Collector  │          │ Manager      │
│            │          │              │
│ Gathers:   │          │ Manages:     │
│ • DNS      │          │ • Rules      │
│ • Gateway  │          │ • Priorities │
│ • Routes   │          │ • Parameters │
│ • Firewall │          │ • Persistence│
└─────┬──────┘          └──────┬───────┘
      │                        │
      └──────────┬─────────────┘
                 │
                 ▼
        ┌────────────────────┐
        │   Rule Engine      │
        │                    │
        │ Applies 13 rules   │
        │ to evidence        │
        │ → Produces findings│
        └────────┬───────────┘
                 │
                 ▼
        ┌────────────────────┐
        │Report Generator    │
        │                    │
        │ Formats findings:  │
        │ • Text  (Unicode)  │
        │ • HTML  (Styled)   │
        │ • JSON  (Structured)
        └────────┬───────────┘
                 │
       ┌─────────┴──────────┐
       │                    │
       ▼                    ▼
  Saved to disk    Displayed to user
```

---

## Project Structure

```
NetworkDiagnosticPlatform/
├── __init__.py                 # Package exports
├── evidence_collector.py        # Windows system evidence gathering
├── rule_engine.py              # Diagnostic rules & finding generation
├── reporting.py                # Multi-format report generation
├── configuration.py            # Configuration & rule management
└── cli.py                       # Command-line interface

tests/
└── NetworkDiagnosticPlatform.Tests/
    ├── test_evidence_collector.py      # Evidence collection tests
    ├── test_rule_engine.py             # Rule engine tests
    ├── test_rule_engine_extended.py    # Extended rule tests
    ├── test_reporting.py               # Basic reporting tests
    ├── test_reporting_extended.py      # Extended reporting tests
    └── test_configuration.py           # Configuration tests

docs/
├── Vision Document.md          # Project vision
├── Architecture.md             # Architecture documentation
├── Implementation Plan.md       # Implementation phases
├── Product Requirements.md      # Detailed requirements
├── Market Analysis.md          # Market research
└── ... (additional documentation)

config/
└── platform.json              # Runtime configuration (generated)

IMPLEMENTATION_REPORT.md        # Phase 2 completion report
DEVELOPER_GUIDE.md             # Development guide
pyproject.toml                 # Project metadata and dependencies
```

---

## Requirements

### System Requirements
- **OS:** Windows 7+ (Windows Server compatible)
- **Python:** 3.10 or higher
- **Disk Space:** <50MB
- **Memory:** Minimal (<100MB)
- **Network:** None required (works offline)

### Dependencies
- **Core:** None (standard library only)
- **Development:** pytest, pytest-cov

### Permissions
- Standard user: Run diagnostics
- Administrator: Full diagnostic collection (recommended)

---

## Usage Examples

### Example 1: Daily Endpoint Health Check

```bash
# Offline testing
python -m NetworkDiagnosticPlatform.cli --offline

# Production diagnostic for employees
python -m NetworkDiagnosticPlatform.cli -o "Z:\Support\Diagnostics" -f "text,html"
```

### Example 2: Bulk Endpoint Diagnostics

```bash
# Create script for IT deployment
for %computer% in (PC001 PC002 PC003) do (
    python -m NetworkDiagnosticPlatform.cli ^
        -H %computer% ^
        -o "\\server\reports\%date%"
)
```

### Example 3: Troubleshooting with Reports

```bash
# Collect detailed diagnostic
python -m NetworkDiagnosticPlatform.cli -o "./troubleshooting" -v

# Open HTML report in browser
start "./troubleshooting/diagnostic_report_*.html"

# Share JSON report with IT team
# Send diagnostic_report_*.json to support
```

---

## Testing

### Run All Tests
```bash
pytest tests/ -v
```

### Test Coverage
```bash
pytest tests/ --cov=NetworkDiagnosticPlatform --cov-report=html
```

### Run Specific Test
```bash
pytest tests/NetworkDiagnosticPlatform.Tests/test_rule_engine.py -v
```

### Test Results
- **Tests:** 42/42 passing ✅
- **Coverage:** 62%
- **Execution Time:** <1 second

---

## Documentation

- **[IMPLEMENTATION_REPORT.md](IMPLEMENTATION_REPORT.md)** - Phase 2 completion details
- **[DEVELOPER_GUIDE.md](DEVELOPER_GUIDE.md)** - Development guide & architecture
- **[docs/](docs/)** - Additional documentation
  - Vision Document
  - Architecture
  - Implementation Plan
  - Product Requirements

---

## Contributing

### Adding a New Diagnostic Rule

See [DEVELOPER_GUIDE.md](DEVELOPER_GUIDE.md#adding-diagnostic-rules) for detailed instructions.

Quick summary:
1. Create rule method in `RuleEngine`
2. Register in `__init__`
3. Add corresponding evidence collection (if needed)
4. Write unit tests
5. Run tests and verify coverage

### Code Standards

- **Style:** PEP 8
- **Type Hints:** Required
- **Docstrings:** Required
- **Tests:** Required
- **Coverage:** Minimum 80%

---

## Performance

| Operation | Time | Notes |
|-----------|------|-------|
| Evidence Collection | 5-30s | Depends on system & network |
| Rule Execution | <100ms | 13 rules evaluated |
| Text Report | <100ms | Box-drawing chars |
| HTML Report | <200ms | Includes CSS |
| JSON Report | <50ms | Lightweight |
| **Total Offline** | <1s | Mock data (no system calls) |

---

## Known Limitations

1. **Windows-Only:** Requires Windows 7+ (Unix/Linux support planned)
2. **Administrator Rights:** Full diagnostics require admin (some info available as user)
3. **Offline Mode:** Uses mock data for testing, not representative of real system
4. **Deterministic Rules Only:** No AI-based diagnosis (by design)
5. **Sequential Collection:** Evidence gathered sequentially (async planned for Phase 3)

---

## Roadmap

### Phase 3 (In Planning)
- [ ] Advanced plugin architecture with third-party rule loading
- [ ] Active Directory and domain integration
- [ ] Historical trend analysis and baseline comparison
- [ ] Bulk endpoint scanning capabilities
- [ ] Centralized reporting dashboard
- [ ] Windows portable executable (.exe) packaging
- [ ] SIEM system integration

### Future Enhancements
- [ ] Real-time monitoring
- [ ] Mobile app for report viewing
- [ ] Integration with ServiceNow/Jira
- [ ] Machine learning for anomaly detection
- [ ] Automated remediation capabilities

---

## Support & Troubleshooting

### Common Issues

**Q: Tests fail with "ImportError"**  
A: Install in development mode: `pip install -e ".[dev]"`

**Q: Reports not being created**  
A: Check output directory exists and is writable: `mkdir -p ./reports`

**Q: Evidence collection hangs**  
A: Press Ctrl+C and run in offline mode: `--offline`

### Getting Help

1. Review [DEVELOPER_GUIDE.md](DEVELOPER_GUIDE.md)
2. Check test examples in `tests/`
3. Review rule implementation in `rule_engine.py`
4. Enable verbose logging: `-v` flag

---

## License & Attribution

This diagnostic platform was developed as an enterprise solution for standardizing Windows endpoint troubleshooting.

### Technologies Used
- Python 3.10+
- Windows PowerShell commands
- pytest for testing
- JSON for persistence

---

## Version History

### v0.1.0 (2026-07-05) - Initial Release
- ✅ Evidence collection layer
- ✅ 13 diagnostic rules
- ✅ Multi-format reporting (Text, HTML, JSON)
- ✅ Configuration management
- ✅ CLI interface
- ✅ Comprehensive test suite (42/42 tests)
- ✅ Production-ready codebase

---

## Status

| Component | Status | Coverage |
|-----------|--------|----------|
| Evidence Collection | ✅ Complete | 34% |
| Rule Engine | ✅ Complete | 92% |
| Reporting | ✅ Complete | 98% |
| Configuration | ✅ Complete | 88% |
| CLI | ✅ Complete | 15%* |
| Overall | ✅ READY | 62% |

*CLI coverage limited by UI testing constraints (functional verified)

---

**Last Updated:** 2026-07-05  
**Version:** 0.1.0  
**Status:** Production Ready ✅
